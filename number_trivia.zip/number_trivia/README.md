# number_trivia

A new Flutter project.

## Aim

This project seeks to explore TDD in a flutter app

## Resources

<https://resocoder.com/category/tutorials/flutter/tdd-clean-architecture/>
